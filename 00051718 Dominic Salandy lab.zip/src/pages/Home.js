import React from 'react'

const Home = () => {
  return (
    <div>
      <h3>Welcome to Movie Time!!!</h3>
      <img src='./images/popcorn.jpg'></img>
    </div>
  )
}

export default Home
