import React from 'react'

const Title = ({mkey,movieData}) => {

 console.log(mkey)
  return (
    <div>
       {movieData.map((movie,i)=> (
        mkey===0 ? <ul key={i}>{movie.title}</ul> :""
       ))}
    </div>
  )
}

export default Title
