import React, { useState } from 'react'
import {Link} from 'react-router-dom'

const Movies = ({movieData}) => {
  const[movieKey,setKey] = useState(0)
  const[movieKey2,setKey2] = useState(1)
 

  return (
    <div>
      <h3>Movies</h3>
      <Link to='/Title' mkey={movieKey}>{movieData.map((e,i)=> i===0 ? e.title : "")} </Link><br></br><br></br>
      <Link to='/Title' mkey={movieKey2}>{movieData.map((e,i)=> i===1 ? e.title : "")}</Link><br></br><br></br>
      <Link to='/Title'>{movieData.map((e,i)=> i===2 ? e.title : "")}</Link><br></br><br></br>
      <Link to='/Title'>{movieData.map((e,i)=> i===3 ? e.title : "")}</Link><br></br><br></br>
      <Link to='/Title'>{movieData.map((e,i)=> i===4 ? e.title : "")}</Link><br></br><br></br>
      <Link to='/Title'>{movieData.map((e,i)=> i===5 ? e.title : "")}</Link><br></br><br></br>
      <Link to='/Title'>{movieData.map((e,i)=> i===6 ? e.title : "")}</Link><br></br><br></br>
      <Link to='/Title'>{movieData.map((e,i)=> i===7 ? e.title : "")}</Link><br></br><br></br>
      <Link to='/Title'>{movieData.map((e,i)=> i===8 ? e.title : "")}</Link><br></br><br></br>
      <Link to='/Title'>{movieData.map((e,i)=> i===9 ? e.title : "")}</Link><br></br><br></br>
    </div>
  )
}

export default Movies
